package de.unihd.movies.client;

import java.util.ArrayList;
import java.util.Comparator;

import com.google.gwt.cell.client.TextCell;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.ColumnSortEvent.ListHandler;
import com.google.gwt.user.client.ui.*;
import com.google.gwt.view.client.ListDataProvider;
;
/**
 * MovieUI that contains a table of movies.
 * */
public class MovieUI extends Composite {

	/**
	 * The main panel which contain all other widgets
	 * */
	private VerticalPanel panel;

	/**
	 * Creates a MovieUI with the given list of movies.
	 * 
	 * @param movies
	 *            The list of movies to show.
	 * */
	public MovieUI(ArrayList<Movie> movieList) {

		panel = new VerticalPanel();
		
//		HorizontalPanel panel = new HorizontalPanel();
//		Label movieTitleLabel = new Label("Movie Title");
//		panel.add(movieTitleLabel);
//
//		TextBox movieTitleTextbox = new TextBox();
//		panel.add(movieTitleTextbox);
				
		// Create a table containing all movies
		CellTable<Movie> movieTable = new CellTable<Movie>();
		Column<Movie, String> idCol = new Column<Movie, String> 
					(new TextCell()) {
			@Override 
			public String getValue(Movie movie) {
				return "" + movie.getId();
			}
		};
		movieTable.addColumn(idCol, "ID");
		Column<Movie, String> nameCol = new Column<Movie, String> 
				(new TextCell()) {
			@Override 
			public String getValue(Movie movie) {
				return "" + movie.getName();
			}
		};
		movieTable.addColumn(nameCol, "Name");
		Column<Movie, String> timeCol = new Column<Movie, String> 
		(new TextCell()) {
			@Override 
			public String getValue(Movie movie) {
				return "" + movie.getTime();
			}
		};
		movieTable.addColumn(timeCol, "Time");
		
		Column<Movie, String> langCol = new Column<Movie, String> 
		(new TextCell()) {
			@Override 
			public String getValue(Movie movie) {
				return "" + movie.getLanguage();
			}
		};
		movieTable.addColumn(langCol, "Language");
		
		Column<Movie, String> descrCol = new Column<Movie, String> 
		(new TextCell()) {
			@Override 
			public String getValue(Movie movie) {
				return "" + movie.getDescription();
			}
		};
		movieTable.addColumn(descrCol, "Description");
		Column<Movie, String> placeCol = new Column<Movie, String> 
		(new TextCell()) {
			@Override 
			public String getValue(Movie movie) {
				return "" + movie.getPlace();
			}
		};
		movieTable.addColumn(placeCol, "Place");
		
		ListDataProvider<Movie> movieDataProvider = new ListDataProvider<Movie>();
		movieDataProvider.setList(movieList);
		movieDataProvider.addDataDisplay(movieTable);
		
		ListHandler<Movie> movieSorter = new ListHandler<Movie>(
				movieDataProvider.getList()
		);
		
		movieSorter.setComparator(idCol, new Comparator<Movie>() 
		{
			@Override
			public int compare(Movie m1, Movie m2) {
				if(m1.getId() > m2.getId()) return 1;
				if(m1.getId() < m2.getId()) return -1;
				return 0;
			};
		});
		idCol.setSortable(true);

		movieSorter.setComparator(nameCol, new Comparator<Movie>() 
		{
			@Override
			public int compare(Movie m1, Movie m2) {
				return (m1.getName().compareTo(m2.getName()));
			};
		});
		nameCol.setSortable(true);
		
		movieSorter.setComparator(timeCol, new Comparator<Movie>() 
		{
			@Override
			public int compare(Movie m1, Movie m2) {
				if(m1.getTime() > m2.getTime()) return 1;
				if(m1.getTime() < m2.getTime()) return -1;
				return 0;
			};
		});
		timeCol.setSortable(true);
		
		movieSorter.setComparator(langCol, new Comparator<Movie>() 
		{
			@Override
			public int compare(Movie m1, Movie m2) {
				return (m1.getLanguage().compareTo(m2.getLanguage()));
			};
		});
		langCol.setSortable(true);
		
		movieSorter.setComparator(descrCol, new Comparator<Movie>() 
		{
			@Override
			public int compare(Movie m1, Movie m2) {
				return (m1.getDescription().compareTo(m2.getDescription()));
			};
		});
		descrCol.setSortable(true);

		movieSorter.setComparator(placeCol, new Comparator<Movie>() 
		{
			@Override
			public int compare(Movie m1, Movie m2) {
				return (m1.getPlace().compareTo(m2.getPlace()));
			};
		});
		placeCol.setSortable(true);
		
		
		movieTable.addColumnSortHandler(movieSorter);
		// Add the table to the panel
		panel.add(movieTable);
	}

	/**
	 * Shows the content of the MovieUI.
	 * */
	public void show() {
		initWidget(panel);
		RootPanel.get("content").add(this);
		this.setVisible(true);
	}

}
