package de.unihd.movies.client;

import java.util.ArrayList;

import com.google.gwt.core.client.EntryPoint;

/**
 * The Class MovieManager.
 */
public class MovieManager implements EntryPoint {
	/**
	 * When module is being loaded, the following function is executed;
	 * here, a movie list is created and the movieUI is instantiated with it
	 */
	public void onModuleLoad() {
		//create some movies		
		final Movie m1 = new Movie(1, "Movie1", 120, "German","great", "here");
		final Movie m2 = new Movie(2, "Movie2", 122, "English","great,too", "there");
		final Movie m3 = new Movie(3, "Movie3", 124, "Spanish","fuego", "or there");
		final Movie m4 = new Movie(4, "Movie4", 126, "Turkish","greater", "maybe there");
		final Movie m5 = new Movie(5, "Movie5", 127, "Greek","greaterer", "probably here");
		final Movie m6 = new Movie(6, "Movie6", 129, "Bavarian","much weißwurst", "somehere");
		final Movie m7 = new Movie(7, "Movie7", 115, "Italiano","greatester", "anyhere");
		final Movie m8 = new Movie(8, "Movie8", 190, "Egyptian","very pharao", "some centuries ago");
		//create movie list
		final ArrayList<Movie> movieList = new ArrayList<Movie>();
		//add movies to list
		movieList.add(m1);
		movieList.add(m2);
		movieList.add(m3);
		movieList.add(m4);
		movieList.add(m5);
		movieList.add(m6);		
		movieList.add(m7);
		movieList.add(m8);
		//instantiate movieUI with movieList
		final MovieUI movieUi = new MovieUI(movieList);
		//show movie table and its functionality
		movieUi.show();
		
	}
	
}
